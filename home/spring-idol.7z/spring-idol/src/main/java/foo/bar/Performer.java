package foo.bar;

/**
 * Created by etc on 20.03.2015.
 */
public interface Performer {
    void perform();
}
