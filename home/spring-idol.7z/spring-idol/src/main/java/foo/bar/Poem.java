package foo.bar;

/**
 * Created by etc on 20.03.2015.
 */
public class Poem {

    public void Poem(){}

    public void recite(){
        System.out.println("reciting cool poem");
    }

}
